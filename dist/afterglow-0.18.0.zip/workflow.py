"""Preflight and a short path from an emissive collection to smooth audio playback."""

import bpy
import numpy as np

from . import bake, core, materials, tempo


def inspect(scene):
    """Return cheap, read-only setup data for the sidebar; do not decode audio on redraw.

    ``targets``, ``eligible``, ``applied``, ``skipped`` and ``shared`` contain objects;
    ``linked`` contains materials. ``reason`` explains the first blocking prerequisite.
    A ready preflight still needs the audio decoder check performed by create_reaction.
    """
    s = scene.afterglow
    targets = core.targets(s.collection) if s.collection else []
    eligible, linked, patched = [], set(), set()
    readonly = []
    for ob in targets:
        if not ob.is_editable:
            readonly.append(ob)
            continue
        emissive = {m for m in core._materials(ob) if materials.has_emission(m)}
        linked.update(m for m in emissive if not m.is_editable)
        local = {m for m in emissive if m.is_editable}
        if local:
            eligible.append(ob)
            patched.update(local)
    eligible_set = set(eligible)
    # Materials can be shared with objects in another scene or an unlinked collection.
    # A patch would darken those users too, so check the whole file before modifying it.
    shared = sorted((ob for ob in bpy.data.objects
                     if ob not in eligible_set and core._materials(ob) & patched),
                    key=lambda ob: ob.name)
    skipped = [ob for ob in targets if ob not in eligible_set]
    applied = [ob for ob in targets if core.find_modifier(ob)]
    warnings = []
    if skipped:
        warnings.append(f"{len(skipped)} objects have no editable emissive material")
    if linked:
        warnings.append(f"{len(linked)} linked materials will stay unchanged")
    if shared:
        warnings.append(f"{len(shared)} other objects share these emissive materials")
    reason = None
    if not s.collection:
        reason = "Choose a collection or use selected glowing objects"
    elif not s.sound:
        reason = "Load a sound file to create the reaction"
    elif not core.sound_ok(s.sound):
        reason = "Sound file is missing; relink it or use a packed sound"
    elif any(ob.name not in scene.objects for ob in targets):
        reason = "Link the chosen collection to this scene first"
    elif readonly:
        reason = "Make linked objects local before creating a reaction"
    elif not eligible:
        reason = "Add a local Emission material to a mesh, curve or text object"
    elif shared:
        reason = ("Make shared emissive materials single-user, or include all their objects "
                  "in the chosen collection")
    elif s.ripple and s.ripple_from == "EMPTY" and s.ripple_origin is None:
        reason = "Choose a Ripple Origin object or another ripple direction"
    return {"collection": s.collection, "sound": s.sound, "targets": targets,
            "eligible": eligible, "applied": applied, "skipped": skipped,
            "linked": sorted(linked, key=lambda mat: mat.name), "shared": shared,
            "ready": reason is None, "reason": reason, "warnings": warnings}


def create_reaction(scene):
    """Apply, calibrate and bake after checking prerequisites without changing the scene.

    Like the existing Calibrate and Fast Playback controls, the final calibration/bake
    refreshes all Afterglow modifiers in this scene. It never builds environment effects.
    """
    state = inspect(scene)
    if not state["ready"]:
        raise ValueError(state["reason"])
    mono, rate = core.load_mono(scene.afterglow.sound, "Create Reaction")
    if not len(mono) or rate <= 0 or not np.isfinite(mono).all():
        raise ValueError("Choose a sound file with readable, finite audio samples")

    # A previous slider edit may still have a deferred bake. This operation replaces it
    # with one final bake after tempo and calibration, rather than running it twice.
    from . import props
    props._pending.pop(scene.name, None)
    applied, skipped, _, linked = core.apply(scene)
    curve = tempo.bake(scene)
    calibrated = core.calibrate(scene)
    if scene.afterglow.fast_playback:
        baked = bake.bake_all(scene)
    else:
        # The property callback synchronizes Use Baked and performs exactly one bake.
        scene.afterglow.fast_playback = True
        if bake.outdated(scene):
            raise ValueError("Fast Playback could not finish; use Re-bake to retry")
        baked = len([ob for ob in core._managed(scene) if core.find_modifier(ob)])
    bpms = [bpm for _, bpm in curve]
    return {"applied": len(applied), "skipped": len(skipped), "linked": len(linked),
            "calibrated": len(calibrated), "baked": baked,
            "bpm": (min(bpms), max(bpms)) if bpms else None}


def use_selected(context):
    """Link eligible selected objects into a local collection, retaining every old link."""
    objects = sorted((ob for ob in context.selected_objects
                      if ob.type in core.SUPPORTED and ob.is_editable
                      and any(m.is_editable and materials.has_emission(m)
                              for m in core._materials(ob))), key=lambda ob: ob.name)
    if not objects:
        raise ValueError("Select meshes, curves or text with local emissive materials first")
    collection = bpy.data.collections.new("Afterglow Selection")
    context.scene.collection.children.link(collection)
    for ob in objects:
        collection.objects.link(ob)
    context.scene.afterglow.collection = collection
    return collection
