"""An additive starter stage and an original, self-contained preview track."""
import math
import os
import tempfile
import wave

import bmesh
import bpy
import numpy as np
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view


TAG = "afterglow_starter"
DURATION = 4.0
RATE = 44100


def camera_for(collection):
    """Find the nearest starter stage's camera, even after nesting its lights collection.

    Name suffixes are deliberately ignored: Blender gives every repeated starter its
    own camera, and an explicitly requested view must select the matching one.
    """
    if collection is None:
        return None
    candidates = []
    for parent in bpy.data.collections:
        if not parent.get(TAG):
            continue
        cameras = [obj for obj in parent.objects if obj.type == "CAMERA" and obj.get(TAG)]
        if not cameras:
            continue
        pending, seen = [(parent, 0)], set()
        while pending:
            current, distance = pending.pop(0)
            if current in seen:
                continue
            seen.add(current)
            if current == collection:
                candidates.append((distance, parent.name, cameras[0]))
                break
            pending.extend((child, distance + 1) for child in current.children)
    return min(candidates, key=lambda item: (item[0], item[1]))[2] if candidates else None


def _preview_sound():
    """Synthesize and pack a short 120-BPM beat; no downloads or external assets."""
    samples = np.zeros(int(DURATION * RATE), dtype=np.float32)

    def add(start, duration, frequency, amplitude, decay):
        offset = int(start * RATE)
        t = np.arange(int(duration * RATE), dtype=np.float32) / RATE
        # A short attack avoids clicks while preserving a clear onset for every beat.
        envelope = np.minimum(t / 0.003, 1.0) * np.exp(-t / decay)
        segment = amplitude * envelope * np.sin(2 * np.pi * frequency * t)
        n = min(len(segment), len(samples) - offset)
        samples[offset:offset + n] += segment[:n]

    for beat in range(8):
        start = 0.125 + beat * 0.5
        add(start, 0.38, 65, 0.8, 0.085)
        add(start + 0.25, 0.16, 440 if beat % 2 else 660, 0.28, 0.045)
        add(start, 0.08, 6500, 0.16, 0.018)
        add(start + 0.25, 0.08, 8800, 0.12, 0.018)
    pcm = (np.clip(samples, -1.0, 1.0) * 30000).astype("<i2")
    fd, path = tempfile.mkstemp(prefix="afterglow-preview-", suffix=".wav")
    os.close(fd)
    sound = None
    try:
        with wave.open(path, "wb") as output:
            output.setnchannels(1)
            output.setsampwidth(2)
            output.setframerate(RATE)
            output.writeframes(pcm.tobytes())
        sound = bpy.data.sounds.load(path, check_existing=False)
        sound.pack()
        sound.name = "Afterglow Preview • 120 BPM"
        sound[TAG] = True
        return sound
    except Exception:
        if sound is not None:
            bpy.data.sounds.remove(sound)
        raise
    finally:
        os.remove(path)


def _cylinder(collection, name, radius, depth, location, material, segments=32):
    mesh = bpy.data.meshes.new(name)
    bm = bmesh.new()
    try:
        bmesh.ops.create_cone(bm, cap_ends=True, segments=segments,
                             radius1=radius, radius2=radius, depth=depth)
        bm.to_mesh(mesh)
    finally:
        bm.free()
    mesh.materials.append(material)
    obj = bpy.data.objects.new(name, mesh)
    obj.location = location
    obj[TAG] = True
    collection.objects.link(obj)
    bevel = obj.modifiers.new("Soft Edges", "BEVEL")
    bevel.width = min(radius * 0.12, depth * 0.1)
    bevel.segments = 3
    for polygon in mesh.polygons:
        polygon.use_smooth = len(polygon.vertices) == 4
    return obj


def _emission_material(name, color):
    material = bpy.data.materials.new(name)
    material.use_nodes = True
    material.diffuse_color = (*color, 1.0)
    tree = material.node_tree
    tree.nodes.clear()
    emission = tree.nodes.new("ShaderNodeEmission")
    emission.inputs["Color"].default_value = (*color, 1.0)
    emission.inputs["Strength"].default_value = 4.0
    output = tree.nodes.new("ShaderNodeOutputMaterial")
    tree.links.new(emission.outputs[0], output.inputs["Surface"])
    return material


def _aim(obj, target):
    obj.rotation_euler = (Vector(target) - obj.location).to_track_quat("-Z", "Y").to_euler()


def _frame_stage(scene, camera, center):
    """Leave breathing room above the columns for the default environment beams."""
    ceiling = 2.25 + scene.afterglow.effects.height
    target = center + Vector((0, 0, ceiling * 0.36))
    offset = Vector((11, -14, 10)) - (target - center)
    effect_radius = 3.26 * scene.afterglow.effects.margin
    bounds = [center + Vector((radius * math.cos(2 * math.pi * step / 32),
                               radius * math.sin(2 * math.pi * step / 32), z))
              for radius, z in ((4.2, -0.18), (effect_radius, ceiling)) for step in range(32)]
    # Respect the user's render aspect ratio without changing it. Moving the new
    # camera backwards fits tall beams in landscape and the stage in portrait.
    for _ in range(24):
        camera.location = target + offset
        _aim(camera, target)
        camera.update_tag()
        bpy.context.view_layer.update()
        coords = [world_to_camera_view(scene, camera, point) for point in bounds]
        if all(0.06 <= co.x <= 0.94 and 0.06 <= co.y <= 0.94 and co.z > 0 for co in coords):
            break
        offset *= 1.12


def create(context):
    """Add a complete preview stage without replacing any scene content or chosen audio.

    The new reactive collection becomes the Afterglow target. Audio is packed into the
    .blend, and the current camera is retained when one already exists. The caller may
    run Create Reaction afterwards; creating a stage itself never applies an effect.
    """
    scene = context.scene
    # Prepare audio first so a packing failure cannot leave a half-created stage.
    sound = _preview_sound() if scene.afterglow.sound is None else None
    center = scene.cursor.location.copy()
    stage = bpy.data.collections.new("Afterglow Starter Stage")
    stage[TAG] = True
    scene.collection.children.link(stage)
    venue = bpy.data.collections.new("Afterglow Starter Lights")
    venue[TAG] = True
    stage.children.link(venue)

    for index in range(12):
        angle = 2 * math.pi * index / 12
        height = 1.7 + 0.55 * (0.5 + 0.5 * math.cos(2 * angle))
        mix = (math.sin(angle) + 1.0) * 0.5
        color = (0.12 + 0.65 * mix, 0.65 - 0.5 * mix, 1.0)
        name = f"Afterglow Column {index + 1:02d}"
        material = _emission_material(name, color)
        _cylinder(venue, name, 0.16, height,
                  center + Vector((3.1 * math.cos(angle), 3.1 * math.sin(angle), height / 2)),
                  material)

    floor_material = bpy.data.materials.new("Afterglow Stage • Graphite")
    floor_material.use_nodes = True
    bsdf = floor_material.node_tree.nodes.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value = (0.025, 0.03, 0.045, 1.0)
    bsdf.inputs["Metallic"].default_value = 0.45
    bsdf.inputs["Roughness"].default_value = 0.32
    _cylinder(stage, "Afterglow Stage", 4.2, 0.18,
              center + Vector((0, 0, -0.09)), floor_material, segments=96)

    for name, position, color, energy in (
        ("Afterglow Key", (0, -1, 6), (0.55, 0.75, 1.0), 900),
        ("Afterglow Rim", (0, 3, 4), (0.8, 0.2, 1.0), 700),
    ):
        light_data = bpy.data.lights.new(name, "AREA")
        light_data.energy, light_data.size, light_data.color = energy, 5.0, color
        light = bpy.data.objects.new(name, light_data)
        stage.objects.link(light)
        light.location = center + Vector(position)
        light[TAG] = True
        _aim(light, center)

    camera_data = bpy.data.cameras.new("Afterglow Stage Camera")
    camera_data.lens = 35
    camera = bpy.data.objects.new("Afterglow Stage Camera", camera_data)
    stage.objects.link(camera)
    camera[TAG] = True
    _frame_stage(scene, camera, center)
    if scene.camera is None:
        scene.camera = camera

    scene.afterglow.collection = venue
    if sound is not None:
        scene.afterglow.sound = sound
    context.view_layer.update()
    return venue
