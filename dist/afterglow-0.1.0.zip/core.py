"""Collection-level operations: apply, respread, sync, remove."""
from . import materials, nodes

SUPPORTED = {"MESH", "CURVE", "FONT"}
MOD_NAME = "Afterglow"
LOW_HZ, HIGH_HZ = 20.0, 16000.0


def targets(collection):
    return sorted((o for o in collection.all_objects if o.type in SUPPORTED), key=lambda o: o.name)


def find_modifier(ob):
    return next((m for m in ob.modifiers
                 if m.type == "NODES" and m.node_group and m.node_group.get(nodes.TAG)), None)


def _materials(ob):
    return {slot.material for slot in ob.material_slots if slot.material}


def _managed(scene):
    """Objects in the current collection plus any object anywhere in the scene that still
    carries an Afterglow modifier (collection switched, object moved out)."""
    objs = {o for o in scene.objects if find_modifier(o)}
    if scene.afterglow.collection:
        objs |= set(targets(scene.afterglow.collection))
    return objs


def band(k, n):
    """Band k of n, log-spaced between LOW_HZ and HIGH_HZ."""
    ratio = HIGH_HZ / LOW_HZ
    return LOW_HZ * ratio ** (k / n), LOW_HZ * ratio ** ((k + 1) / n)


def apply(scene):
    """Add or refresh the modifier and patch materials on every emissive object in the collection.

    Returns (applied, skipped, outside, linked). 'outside' lists objects outside the collection
    that share a patched material; they have no Afterglow attributes, so they render dark.
    'linked' lists library-linked emissive materials, which can't be patched persistently.
    """
    s = scene.afterglow
    if s.collection is None:
        raise ValueError("Pick a collection first")
    if s.sound is None:
        raise ValueError("Pick a sound file first")
    group = nodes.get_group()
    applied, skipped, patched, linked = [], [], set(), []
    for ob in targets(s.collection):
        mats = set()
        for m in _materials(ob):
            if not materials.has_emission(m):
                continue
            if m.library:
                if m not in linked:
                    linked.append(m)
            else:
                mats.add(m)
        if not mats:
            skipped.append(ob)
            continue
        mod = find_modifier(ob) or ob.modifiers.new(MOD_NAME, "NODES")
        mod.node_group = group
        nodes.set_input(mod, "Sound", s.sound)
        nodes.set_input(mod, "Start Frame", s.start_frame)
        for m in mats:
            materials.patch_material(m)
        patched |= mats
        applied.append(ob)
    respread(applied)
    outside = [o for o in scene.objects if o not in applied and _materials(o) & patched]
    return applied, skipped, outside, linked


def respread(objs):
    free = [o for o in objs if not o.afterglow.locked]
    for k, ob in enumerate(free):
        low, high = band(k, len(free))
        mod = find_modifier(ob)
        nodes.set_input(mod, "Low", low)
        nodes.set_input(mod, "High", high)


def sync(scene):
    """Push the scene-wide Sound and Start Frame into every Afterglow modifier."""
    s = scene.afterglow
    for ob in _managed(scene):
        mod = find_modifier(ob)
        if mod:
            nodes.set_input(mod, "Sound", s.sound)
            nodes.set_input(mod, "Start Frame", s.start_frame)


def remove(scene):
    for ob in _managed(scene):
        mod = find_modifier(ob)
        if mod:
            ob.modifiers.remove(mod)
        for m in _materials(ob):
            materials.unpatch_material(m)
