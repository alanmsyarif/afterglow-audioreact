"""The shared Afterglow geometry node group and modifier input helpers."""
import bpy

GROUP_NAME = "Afterglow AudioReact"
SAMPLES = 8  # ponytail: fixed smoothing sample count; expose it if long tails get steppy

# (name, socket type, default). Every float input is clamped to >= 0.
INPUTS = (
    ("Sound", "NodeSocketSound", None),
    ("Start Frame", "NodeSocketInt", 1),
    ("Low", "NodeSocketFloat", 20.0),
    ("High", "NodeSocketFloat", 200.0),
    ("Gain", "NodeSocketFloat", 1.0),
    ("Threshold", "NodeSocketFloat", 0.0),
    ("Decay", "NodeSocketFloat", 0.15),
    ("Delay", "NodeSocketFloat", 0.0),
    ("Use Colors", "NodeSocketBool", False),
    ("Color A", "NodeSocketColor", (1.0, 1.0, 1.0, 1.0)),
    ("Color B", "NodeSocketColor", (1.0, 1.0, 1.0, 1.0)),
)
OBJECT_INPUTS = [name for name, _, _ in INPUTS if name not in {"Sound", "Start Frame"}]


TAG = "afterglow"


def get_group():
    """The Afterglow group, found by tag so renamed or appended copies are reused."""
    return next((g for g in bpy.data.node_groups if g.get(TAG)), None) or _build()


def _socket(mod, name):
    return getattr(mod.properties.inputs, mod.node_group.interface.items_tree[name].identifier)


def set_input(mod, name, value):
    _socket(mod, name).value = value


def get_input(mod, name):
    return _socket(mod, name).value


def draw_input(layout, mod, name):
    layout.prop(_socket(mod, name), "value", text=name)


def _build():
    ng = bpy.data.node_groups.new(GROUP_NAME, "GeometryNodeTree")
    ng.is_modifier = True
    ng[TAG] = 1
    it = ng.interface
    it.new_socket("Geometry", in_out="INPUT", socket_type="NodeSocketGeometry")
    it.new_socket("Geometry", in_out="OUTPUT", socket_type="NodeSocketGeometry")
    for name, socket_type, default in INPUTS:
        s = it.new_socket(name, in_out="INPUT", socket_type=socket_type)
        if default is not None:
            s.default_value = default
        if socket_type == "NodeSocketFloat":
            s.min_value = 0.0

    N, L = ng.nodes, ng.links

    def op(operation, a, b=0.0):
        n = N.new("ShaderNodeMath")
        n.operation = operation
        for socket, v in zip(n.inputs, (a, b)):
            if isinstance(v, bpy.types.NodeSocket):
                L.new(v, socket)
            else:
                socket.default_value = v
        return n.outputs[0]

    gi, go = N.new("NodeGroupInput"), N.new("NodeGroupOutput")
    g = gi.outputs
    st = N.new("GeometryNodeInputSceneTime")
    # Geometry nodes can't read fps; Seconds / Frame recovers it.
    # At frame 0 this is 0/0 = 0; the frame gate below keeps frame 0 dark when Start Frame >= 1.
    spf = op("DIVIDE", st.outputs["Seconds"], st.outputs["Frame"])
    t = op("SUBTRACT", op("MULTIPLY", op("SUBTRACT", st.outputs["Frame"], g["Start Frame"]), spf), g["Delay"])
    step = op("MULTIPLY", g["Decay"], 0.25)
    decay = op("MAXIMUM", g["Decay"], 1e-4)

    # Peak-hold with exponential release: max over i of amp(t - i*step) * exp(-i*step / decay)
    ri, ro = N.new("GeometryNodeRepeatInput"), N.new("GeometryNodeRepeatOutput")
    ri.pair_with_output(ro)
    ro.repeat_items.new("FLOAT", "Peak")
    ri.inputs["Iterations"].default_value = SAMPLES
    age = op("MULTIPLY", ri.outputs["Iteration"], step)
    sample_t = op("SUBTRACT", t, age)
    ss = N.new("GeometryNodeSampleSoundFrequencies")
    L.new(g["Sound"], ss.inputs["Sound"])
    L.new(sample_t, ss.inputs["Time"])
    L.new(g["Low"], ss.inputs["Low"])
    L.new(g["High"], ss.inputs["High"])
    weight = op("EXPONENT", op("DIVIDE", age, op("MULTIPLY", decay, -1.0)))
    # 0 before the audio starts: by sample time, and by frame (covers frame 0's missing fps)
    gate = op("MULTIPLY", op("SUBTRACT", 1.0, op("LESS_THAN", sample_t, 0.0)),
              op("SUBTRACT", 1.0, op("LESS_THAN", st.outputs["Frame"], g["Start Frame"])))
    weighted = op("MULTIPLY", op("MULTIPLY", ss.outputs["Amplitude"], weight), gate)
    L.new(op("MAXIMUM", ri.outputs["Peak"], weighted), ro.inputs["Peak"])

    level = op("MULTIPLY", op("MAXIMUM", op("SUBTRACT", ro.outputs["Peak"], g["Threshold"]), 0.0), g["Gain"])
    mix = N.new("ShaderNodeMix")
    mix.data_type = "RGBA"
    L.new(level, mix.inputs[0])         # Factor (clamped to 0..1)
    L.new(g["Color A"], mix.inputs[6])  # A_Color
    L.new(g["Color B"], mix.inputs[7])  # B_Color

    realize = N.new("GeometryNodeRealizeInstances")
    L.new(g["Geometry"], realize.inputs[0])
    out = realize.outputs[0]
    for name, data_type, value in (
        ("ar_level", "FLOAT", level),
        ("ar_color", "FLOAT_COLOR", mix.outputs[2]),
        ("ar_tint", "FLOAT", g["Use Colors"]),
    ):
        store = N.new("GeometryNodeStoreNamedAttribute")
        store.data_type = data_type
        store.domain = "POINT"
        store.inputs["Name"].default_value = name
        L.new(out, store.inputs["Geometry"])
        L.new(value, store.inputs["Value"])
        out = store.outputs["Geometry"]
    L.new(out, go.inputs["Geometry"])

    for i, n in enumerate(N):  # ponytail: one row so the tree is at least untangled if opened
        n.location = (i * 180, 0)
    return ng
