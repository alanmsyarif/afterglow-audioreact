"""Patch emission inputs to read Afterglow attributes, and undo it exactly."""
TAG = "afterglow"


def _targets(nt):
    """Yield (node, strength socket, color socket) for every emission input in the tree."""
    for n in nt.nodes:
        if n.get(TAG):
            continue
        if n.bl_idname == "ShaderNodeEmission":
            yield n, n.inputs["Strength"], n.inputs["Color"]
        elif n.bl_idname == "ShaderNodeBsdfPrincipled":
            s = n.inputs["Emission Strength"]
            if s.is_linked or s.default_value > 0:
                yield n, s, n.inputs["Emission Color"]


def has_emission(mat):
    return bool(mat and mat.node_tree and next(_targets(mat.node_tree), None))


def is_patched(mat):
    return bool(mat and mat.node_tree) and any(n.get(TAG) for n in mat.node_tree.nodes)


def _new(nt, idname, near, dx, dy=0):
    n = nt.nodes.new(idname)
    n[TAG] = 1
    n.label = "Afterglow"
    n.location = (near.location.x - dx, near.location.y - dy)
    return n


def _route(nt, patch, orig_index, out, node, target):
    """Move target's original link/value into patch.inputs[orig_index], then feed target from out."""
    src = patch.inputs[orig_index]
    if target.is_linked:
        nt.links.new(target.links[0].from_socket, src)
    else:
        src.default_value = target.default_value
    nt.links.new(out, target)
    patch[TAG + "_to"] = node.name + "|" + target.identifier
    patch[TAG + "_from"] = orig_index


def patch_material(mat):
    if not has_emission(mat) or is_patched(mat):
        return False
    nt = mat.node_tree
    for node, strength, color in list(_targets(nt)):
        attrs = {}
        for i, name in enumerate(("ar_level", "ar_tint", "ar_color")):
            a = _new(nt, "ShaderNodeAttribute", node, 500, i * 160)
            a.attribute_type = "GEOMETRY"
            a.attribute_name = name
            attrs[name] = a
        mul = _new(nt, "ShaderNodeMath", node, 250)
        mul.operation = "MULTIPLY"
        nt.links.new(attrs["ar_level"].outputs["Fac"], mul.inputs[1])
        _route(nt, mul, 0, mul.outputs[0], node, strength)
        mix = _new(nt, "ShaderNodeMix", node, 250, 200)
        mix.data_type = "RGBA"
        nt.links.new(attrs["ar_tint"].outputs["Fac"], mix.inputs[0])
        nt.links.new(attrs["ar_color"].outputs["Color"], mix.inputs[7])
        _route(nt, mix, 6, mix.outputs[2], node, color)
    return True


def unpatch_material(mat):
    if not is_patched(mat):
        return False
    nt = mat.node_tree
    tagged = [n for n in nt.nodes if n.get(TAG)]
    for patch in tagged:
        to = patch.get(TAG + "_to")
        if not to:
            continue
        # The patch's own output link survives renames; the stored name is the fallback.
        target = next((l.to_socket for o in patch.outputs for l in o.links if not l.to_node.get(TAG)), None)
        if target is None:
            node_name, ident = to.rsplit("|", 1)
            node = nt.nodes.get(node_name)
            target = node and next((s for s in node.inputs if s.identifier == ident), None)
        if target is None:
            continue  # user deleted the target; nothing to restore
        src = patch.inputs[patch[TAG + "_from"]]
        if src.is_linked:
            nt.links.new(src.links[0].from_socket, target)
        else:
            target.default_value = src.default_value
    for n in tagged:
        nt.nodes.remove(n)
    return True
