"""The shared Afterglow geometry node group and modifier input helpers."""
import bpy

GROUP_NAME = "Afterglow AudioReact"
TAG = "afterglow"
VERSION = 4  # bump when the interface changes; get_group() migrates older groups
SAMPLES = 8  # ponytail: fixed smoothing sample count; expose it if long tails get steppy
BEAT_NODE = "Beat Length"
TEMPO_TAGS = ("afterglow_tempo_path", "afterglow_tempo_start")  # set by tempo.bake on the group
KICK = (40.0, 150.0)

# (name, socket type, default). Every float input is clamped to >= 0. Append only:
# socket identifiers follow creation order and migration relies on them.
INPUTS = (
    ("Sound", "NodeSocketSound", None),
    ("Start Frame", "NodeSocketInt", 1),
    ("Low", "NodeSocketFloat", 20.0),
    ("High", "NodeSocketFloat", 200.0),
    ("Gain", "NodeSocketFloat", 1.0),
    ("Threshold", "NodeSocketFloat", 0.0),
    ("Decay", "NodeSocketFloat", 0.15),
    ("Delay", "NodeSocketFloat", 0.0),
    ("Use Colors", "NodeSocketBool", False),
    ("Color A", "NodeSocketColor", (1.0, 1.0, 1.0, 1.0)),
    ("Color B", "NodeSocketColor", (1.0, 1.0, 1.0, 1.0)),
    ("Ripple", "NodeSocketBool", False),
    ("Beats per Sweep", "NodeSocketFloat", 1.0),
    ("Ripple Position", "NodeSocketFloat", 0.0),
    ("Ripple Gain", "NodeSocketFloat", 1.0),       # used instead of Gain/Threshold while
    ("Ripple Threshold", "NodeSocketFloat", 0.0),  # rippling: the kick band has its own scale
    ("Use Baked", "NodeSocketBool", False),    # Fast Playback: read Baked Peak, skip the sound node
    ("Baked Peak", "NodeSocketFloat", 0.0),    # keyed per frame by bake.py
)
SCENE_INPUTS = {"Sound", "Start Frame", "Ripple", "Beats per Sweep", "Use Baked"}
RIPPLE_PAIR = {"Gain": "Ripple Gain", "Threshold": "Ripple Threshold"}
OBJECT_INPUTS = [name for name, _, _ in INPUTS
                 if name not in SCENE_INPUTS | {"Ripple Position", "Baked Peak"} | set(RIPPLE_PAIR.values())]


def _current():
    return next((g for g in bpy.data.node_groups if g.get(TAG, 0) >= VERSION), None)


def migrate():
    """Move modifiers off groups built by an older VERSION, keeping their input values.
    A cheap no-op when there are none, so anything touching modifier inputs can call it."""
    old = [g for g in bpy.data.node_groups if 0 < g.get(TAG, 0) < VERSION]
    if not old:
        return
    group = _current() or _build()
    for g in old:
        _carry_tempo(g, group)
        for ob in bpy.data.objects:
            for m in ob.modifiers:
                if m.type == "NODES" and m.node_group == g:
                    m.node_group = group
                    ob.update_tag()
        bpy.data.node_groups.remove(g)
    group.name = GROUP_NAME


def _carry_tempo(old, new):
    """Keep the old group's Beat Length curve (and the user's hand edits) on the new group."""
    oad = old.animation_data
    if not (oad and oad.action) or (new.animation_data and new.animation_data.action):
        return
    ident = oad.action_slot.identifier if oad.action_slot else None
    nad = new.animation_data_create()
    nad.action = oad.action
    slot = next((sl for sl in nad.action.slots if sl.identifier == ident), None)
    if slot:
        nad.action_slot = slot
    for key in TEMPO_TAGS:
        if key in old:
            new[key] = old[key]


def get_group():
    """The current Afterglow group, found by tag so renamed copies are reused."""
    migrate()
    return _current() or _build()


def _socket(mod, name):
    return getattr(mod.properties.inputs, mod.node_group.interface.items_tree[name].identifier)


def set_input(mod, name, value):
    _socket(mod, name).value = value
    mod.id_data.update_tag()  # 5.2: setting properties.inputs from Python doesn't tag the depsgraph


def get_input(mod, name):
    return _socket(mod, name).value


def draw_input(layout, mod, name):
    layout.prop(_socket(mod, name), "value", text=name)


def _build():
    ng = bpy.data.node_groups.new(GROUP_NAME, "GeometryNodeTree")
    ng.is_modifier = True
    ng[TAG] = VERSION
    it = ng.interface
    it.new_socket("Geometry", in_out="INPUT", socket_type="NodeSocketGeometry")
    it.new_socket("Geometry", in_out="OUTPUT", socket_type="NodeSocketGeometry")
    for name, socket_type, default in INPUTS:
        s = it.new_socket(name, in_out="INPUT", socket_type=socket_type)
        if default is not None:
            s.default_value = default
        if socket_type == "NodeSocketFloat":
            s.min_value = 0.0
        if name == "Ripple Position":
            s.max_value = 1.0

    N, L = ng.nodes, ng.links

    def op(operation, a, b=0.0):
        n = N.new("ShaderNodeMath")
        n.operation = operation
        for socket, v in zip(n.inputs, (a, b)):
            if isinstance(v, bpy.types.NodeSocket):
                L.new(v, socket)
            else:
                socket.default_value = v
        return n.outputs[0]

    gi, go = N.new("NodeGroupInput"), N.new("NodeGroupOutput")
    g = gi.outputs
    beat = N.new("ShaderNodeValue")
    beat.name = beat.label = BEAT_NODE
    beat.outputs[0].default_value = 0.5  # seconds per beat (120 BPM) until tempo.bake keys it

    # Ripple: everyone listens to the kick band and lags by position x sweep length.
    low = op("ADD", g["Low"], op("MULTIPLY", g["Ripple"], op("SUBTRACT", KICK[0], g["Low"])))
    high = op("ADD", g["High"], op("MULTIPLY", g["Ripple"], op("SUBTRACT", KICK[1], g["High"])))
    lag = op("MULTIPLY", op("MULTIPLY", g["Ripple"], g["Ripple Position"]),
             op("MULTIPLY", g["Beats per Sweep"], beat.outputs[0]))
    delay = op("ADD", g["Delay"], lag)

    st = N.new("GeometryNodeInputSceneTime")
    # Geometry nodes can't read fps; Seconds / Frame recovers it.
    # At frame 0 this is 0/0 = 0; the frame gate below keeps frame 0 dark when Start Frame >= 1.
    spf = op("DIVIDE", st.outputs["Seconds"], st.outputs["Frame"])
    t = op("SUBTRACT", op("MULTIPLY", op("SUBTRACT", st.outputs["Frame"], g["Start Frame"]), spf), delay)
    step = op("MULTIPLY", g["Decay"], 0.25)
    decay = op("MAXIMUM", g["Decay"], 1e-4)

    # Peak-hold with exponential release: max over i of amp(t - i*step) * exp(-i*step / decay)
    ri, ro = N.new("GeometryNodeRepeatInput"), N.new("GeometryNodeRepeatOutput")
    ri.pair_with_output(ro)
    ro.repeat_items.new("FLOAT", "Peak")
    ri.inputs["Iterations"].default_value = SAMPLES
    age = op("MULTIPLY", ri.outputs["Iteration"], step)
    sample_t = op("SUBTRACT", t, age)
    ss = N.new("GeometryNodeSampleSoundFrequencies")
    L.new(g["Sound"], ss.inputs["Sound"])
    L.new(sample_t, ss.inputs["Time"])
    L.new(low, ss.inputs["Low"])
    L.new(high, ss.inputs["High"])
    weight = op("EXPONENT", op("DIVIDE", age, op("MULTIPLY", decay, -1.0)))
    # 0 before the audio starts: by sample time, and by frame (covers frame 0's missing fps)
    gate = op("MULTIPLY", op("SUBTRACT", 1.0, op("LESS_THAN", sample_t, 0.0)),
              op("SUBTRACT", 1.0, op("LESS_THAN", st.outputs["Frame"], g["Start Frame"])))
    weighted = op("MULTIPLY", op("MULTIPLY", ss.outputs["Amplitude"], weight), gate)
    L.new(op("MAXIMUM", ri.outputs["Peak"], weighted), ro.inputs["Peak"])

    gain = op("ADD", g["Gain"], op("MULTIPLY", g["Ripple"], op("SUBTRACT", g["Ripple Gain"], g["Gain"])))
    threshold = op("ADD", g["Threshold"],
                   op("MULTIPLY", g["Ripple"], op("SUBTRACT", g["Ripple Threshold"], g["Threshold"])))
    # Fast Playback: a lazy Switch, so the Sample Sound branch isn't evaluated when baked.
    baked = N.new("GeometryNodeSwitch")
    baked.input_type = "FLOAT"
    L.new(g["Use Baked"], baked.inputs["Switch"])
    L.new(ro.outputs["Peak"], baked.inputs["False"])
    L.new(g["Baked Peak"], baked.inputs["True"])
    level = op("MULTIPLY", op("MAXIMUM", op("SUBTRACT", baked.outputs[0], threshold), 0.0), gain)
    mix = N.new("ShaderNodeMix")
    mix.data_type = "RGBA"
    L.new(level, mix.inputs[0])         # Factor (clamped to 0..1)
    L.new(g["Color A"], mix.inputs[6])  # A_Color
    L.new(g["Color B"], mix.inputs[7])  # B_Color

    realize = N.new("GeometryNodeRealizeInstances")
    L.new(g["Geometry"], realize.inputs[0])
    out = realize.outputs[0]
    for name, data_type, value in (
        ("ar_level", "FLOAT", level),
        ("ar_color", "FLOAT_COLOR", mix.outputs[2]),
        ("ar_tint", "FLOAT", g["Use Colors"]),
    ):
        store = N.new("GeometryNodeStoreNamedAttribute")
        store.data_type = data_type
        store.domain = "POINT"
        store.inputs["Name"].default_value = name
        L.new(out, store.inputs["Geometry"])
        L.new(value, store.inputs["Value"])
        out = store.outputs["Geometry"]
    L.new(out, go.inputs["Geometry"])

    for i, n in enumerate(N):  # ponytail: one row so the tree is at least untangled if opened
        n.location = (i * 180, 0)
    return ng
